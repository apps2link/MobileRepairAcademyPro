package com.mobilerepair.academy.data

data class QuizQ(val q: String, val options: List<String>, val answer: Int, val explain: String)

data class Lesson(
    val id: String, val level: Int, val title: String, val difficulty: String,
    val goals: List<String>, val body: String, val steps: List<String>,
    val tools: List<String>, val mistakes: List<String>, val safety: List<String>,
    val quiz: List<QuizQ>, val sources: List<String>, val reviewed: String
)

data class Component(
    val id: String, val nameAr: String, val nameEn: String, val function: String,
    val symbol: String, val identify: String, val measure: String, val meterMode: String,
    val expected: String, val interpret: List<String>, val faults: List<String>,
    val example: String, val sources: List<String>, val reviewed: String
)

data class FaultTest(val goal: String, val tools: String, val how: String, val interpret: List<String>)

data class FaultFlow(
    val id: String, val title: String, val keywords: List<String>,
    val questions: List<String>, val tests: List<FaultTest>, val cautions: List<String>
)

data class LibraryItem(
    val id: String, val company: String, val model: String, val kind: String,
    val title: String, val url: String, val source: String, val license: String
)

data class CompatItem(
    val original: String, val alt: String, val partNumber: String, val kind: String,
    val source: String, val verified: String, val notes: String, val certainty: String, val review: String
)

data class SearchResult(
    val title: String, val url: String, val snippet: String,
    val source: String, val kind: String, val score: Double = 0.0
)

val LEVEL_NAMES = mapOf(
    1 to "المستوى الأول: أساسيات الصيانة",
    2 to "المستوى الثاني: المكونات الإلكترونية",
    3 to "المستوى الثالث: دوائر الهاتف",
    4 to "المستوى الرابع: الصيانة العملية",
    5 to "المستوى الخامس: التشخيص المتقدم",
    6 to "المستوى السادس: التخصص حسب الشركة"
)
