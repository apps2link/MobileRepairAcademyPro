package com.mobilerepair.academy.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF00E5A0), onPrimary = Color(0xFF00382A),
    secondary = Color(0xFFFFB300), onSecondary = Color(0xFF2B1D00),
    background = Color(0xFF0B1512), onBackground = Color(0xFFE3F2EC),
    surface = Color(0xFF12201C), onSurface = Color(0xFFE3F2EC),
    surfaceVariant = Color(0xFF1B2D27), onSurfaceVariant = Color(0xFFB7CCC4),
    error = Color(0xFFFF6B6B)
)
private val Light = lightColorScheme(
    primary = Color(0xFF00694B), onPrimary = Color.White,
    secondary = Color(0xFF8A5A00), onSecondary = Color.White,
    background = Color(0xFFF3F8F5), onBackground = Color(0xFF101C18),
    surface = Color.White, onSurface = Color(0xFF101C18),
    surfaceVariant = Color(0xFFDDEBE5), onSurfaceVariant = Color(0xFF3A4A44),
    error = Color(0xFFB3261E)
)

@Composable
fun AppTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
