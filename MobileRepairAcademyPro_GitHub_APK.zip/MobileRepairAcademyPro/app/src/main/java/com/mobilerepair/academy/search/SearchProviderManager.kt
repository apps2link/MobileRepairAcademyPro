package com.mobilerepair.academy.search

import android.content.Context
import com.mobilerepair.academy.data.*
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SearchRequest(
    val description: String, val company: String, val model: String,
    val faultType: String, val extra: String, val lang: String, val kinds: Set<String>
)

data class SearchReport(
    val outcomes: List<ConnOutcome>, val results: List<SearchResult>,
    val reportText: String, val confidence: String, val offline: Boolean
)

class SearchProviderManager(private val ctx: Context, private val prefs: Prefs, private val content: ContentRepository) {

    /** Add or replace connectors here without touching UI code. */
    val connectors: List<SearchConnector> = listOf(
        IFixitConnector(), RedditConnector(), DuckDuckGoInstantConnector(),
        BraveConnector(prefs), GoogleCseConnector(prefs), YouTubeConnector(prefs), OpenSerpConnector(prefs)
    )

    private val techSites = "(site:gsmarena.com OR site:xda-developers.com OR site:forum.gsmhosting.com OR site:ifixit.com OR site:reddit.com)"

    fun buildQuery(r: SearchRequest): String {
        val base = listOf(r.company, r.model, r.faultType, r.description, r.extra).filter { it.isNotBlank() }.joinToString(" ")
        return when (r.lang) { "ar" -> "$base حل صيانة"; "en" -> "$base fix repair"; else -> base }.trim()
    }

    suspend fun run(r: SearchRequest): SearchReport = coroutineScope {
        val query = buildQuery(r)
        if (!isOnline(ctx)) {
            val outs = connectors.map { ConnOutcome(it.name, ConnStatus.UNAVAILABLE, "مفيش إنترنت") }
            return@coroutineScope SearchReport(outs, emptyList(),
                "مفيش اتصال بالإنترنت دلوقتي، فالبحث المباشر مش متاح. تقدر ترجع للدروس والموسوعة المحفوظة.", "غير كافٍ للحكم", true)
        }
        val outcomes = connectors.map { c ->
            async {
                val missing = c.missingSetup()
                if (missing != null) return@async ConnOutcome(c.name, ConnStatus.UNAVAILABLE, missing)
                try {
                    val queries = if (c.general) listOf(query, "$techSites ${query}") else listOf(query)
                    val res = withTimeout(25_000) { queries.flatMap { c.search(it) } }
                    ConnOutcome(c.name, ConnStatus.OK, "${res.size} نتيجة", res)
                } catch (e: TimeoutCancellationException) {
                    ConnOutcome(c.name, ConnStatus.FAILED, "انتهت المهلة")
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    ConnOutcome(c.name, ConnStatus.FAILED, e.message ?: e.javaClass.simpleName)
                }
            }
        }.awaitAll()

        val filtered = outcomes.flatMap { it.results }
            .filter { r.kinds.isEmpty() || it.kind in r.kinds }
        val ranked = ResultRanker.rank(filtered, query, r.model).take(20)
        val confidence = if (ranked.isEmpty()) "غير كافٍ للحكم" else "احتمال يحتاج إلى اختبار"
        SearchReport(outcomes, ranked, buildReport(r, outcomes, ranked, confidence), confidence, false)
    }

    private fun buildReport(r: SearchRequest, outs: List<ConnOutcome>, ranked: List<SearchResult>, conf: String): String {
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val sb = StringBuilder()
        sb.appendLine("1) ملخص العطل")
        sb.appendLine("${listOf(r.company, r.model).filter { it.isNotBlank() }.joinToString(" ")} — ${r.description.ifBlank { r.faultType }}".trim())
        sb.appendLine()
        sb.appendLine("2) اللي حصل في البحث (بتاريخ $date)")
        outs.forEach {
            val s = when (it.status) { ConnStatus.OK -> "اشتغل"; ConnStatus.FAILED -> "فشل"; ConnStatus.UNAVAILABLE -> "مش متاح" }
            sb.appendLine("• ${it.name}: $s (${it.message})")
        }
        sb.appendLine()
        if (ranked.isEmpty()) {
            sb.appendLine("3) النتايج\nمفيش نتايج كفاية. جرّب كلمات تانية أو أضف موديل أدق، أو فعّل محرك بحث من الإعدادات.")
        } else {
            sb.appendLine("3) النتايج مترتبة حسب الصلة بالموديل والعطل")
            sb.appendLine("ملحوظة مهمة: الترتيب بيعتمد على العناوين والمقتطفات فقط، ومفتحتش الصفحات ولا قريت محتواها. عدد النتايج مش دليل إن الحل صح.")
        }
        sb.appendLine()
        val flow = FaultMatcher.match(listOf(r.description, r.faultType, r.extra).joinToString(" "), content.faults)
        sb.appendLine("4) درجة التأكد: $conf")
        sb.appendLine()
        sb.appendLine("5) الخطوة اللي بعدها")
        val t = flow?.tests?.firstOrNull()
        sb.appendLine(if (t != null) "جرّب الاختبار ده وابعتلي نتيجته للمهندس الذكي: ${t.goal} — ${t.how}"
        else "افتح مهندس الصيانة الذكي وابعتله وصف العطل والموديل، وهيطلب منك اختبار مناسب.")
        return sb.toString().trim()
    }
}
