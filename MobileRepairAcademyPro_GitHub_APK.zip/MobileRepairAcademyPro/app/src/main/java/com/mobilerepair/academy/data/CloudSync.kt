package com.mobilerepair.academy.data

/** Cloud layer placeholder. Replace with a real backend (e.g. Firebase) without touching the UI. */
interface CloudSync {
    val configured: Boolean
    suspend fun pushContribution(c: ContributionEntity): Boolean
    suspend fun pullApprovedContent(): Boolean
}

class NoopCloudSync : CloudSync {
    override val configured = false
    override suspend fun pushContribution(c: ContributionEntity) = false
    override suspend fun pullApprovedContent() = false
}
