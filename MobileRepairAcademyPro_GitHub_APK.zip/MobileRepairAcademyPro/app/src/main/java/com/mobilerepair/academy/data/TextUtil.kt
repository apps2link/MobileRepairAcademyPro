package com.mobilerepair.academy.data

object TextUtil {
    private val diacritics = Regex("[\\u064B-\\u0652\\u0640]")
    private val splitter = Regex("[^\\p{L}\\p{N}]+")

    fun normalize(s: String): String =
        s.lowercase().replace(diacritics, "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ة', 'ه').replace('ى', 'ي')

    fun tokens(s: String): List<String> =
        normalize(s).split(splitter).filter { it.length >= 2 }
}

object FaultMatcher {
    /** Returns the flow with the most keyword hits, or null when nothing matches. */
    fun match(text: String, flows: List<FaultFlow>): FaultFlow? {
        val t = TextUtil.normalize(text)
        return flows
            .map { f -> f to f.keywords.count { k -> t.contains(TextUtil.normalize(k)) } }
            .filter { it.second > 0 }
            .maxByOrNull { it.second }?.first
    }
}

object ResultRanker {
    fun normUrl(u: String): String {
        var s = u.trim().lowercase().removePrefix("https://").removePrefix("http://").removePrefix("www.")
        s = s.substringBefore('#')
        if (s.contains('?')) {
            val base = s.substringBefore('?')
            val q = s.substringAfter('?').split('&').filter { it.isNotEmpty() && !it.startsWith("utm_") }
            s = if (q.isEmpty()) base else base + "?" + q.joinToString("&")
        }
        return s.trimEnd('/')
    }

    fun dedupe(list: List<SearchResult>): List<SearchResult> = list.distinctBy { normUrl(it.url) }

    fun trust(kind: String): Double = when (kind) {
        "official" -> 3.0
        "reference" -> 2.5
        "forum" -> 1.5
        else -> 1.0
    }

    fun rank(list: List<SearchResult>, query: String, model: String): List<SearchResult> {
        val qt = TextUtil.tokens(query)
        val mt = TextUtil.tokens(model)
        return dedupe(list).map { r ->
            val hay = TextUtil.normalize(r.title + " " + r.snippet + " " + r.url)
            val overlap = qt.count { hay.contains(it) }.toDouble() / maxOf(1, qt.size)
            val modelBonus = if (mt.isNotEmpty() && mt.all { hay.contains(it) }) 3.0 else 0.0
            r.copy(score = overlap * 3.0 + trust(r.kind) + modelBonus)
        }.sortedByDescending { it.score }
    }
}
