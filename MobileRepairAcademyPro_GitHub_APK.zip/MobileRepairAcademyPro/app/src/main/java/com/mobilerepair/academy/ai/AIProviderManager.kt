package com.mobilerepair.academy.ai

import android.content.Context
import com.mobilerepair.academy.data.*
import com.mobilerepair.academy.search.isOnline
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withTimeout

data class ProviderState(val name: String, val state: String)
data class AiStatus(
    val current: String = "لسه ما اتجرّبش",
    val generative: Boolean = false,
    val lastError: String? = null,
    val states: List<ProviderState> = emptyList(),
    val online: Boolean = true
)

class AIProviderManager(private val ctx: Context, private val prefs: Prefs, content: ContentRepository) {
    /** Order matters: local -> user provider -> public keyless -> rule-based fallback. New providers can be appended here. */
    private val providers: List<AiProvider> = listOf(LocalModelProvider(), OpenAiCompatProvider(prefs), PublicKeylessProvider(prefs))
    private val rule = RuleBasedProvider(content)

    private val _status = MutableStateFlow(AiStatus())
    val status: StateFlow<AiStatus> = _status

    val supportsImages: Boolean get() = providers.any { it.configured() && it.supportsImages }

    suspend fun chat(history: List<ChatMsg>, level: String, device: String): AiResult {
        val online = isOnline(ctx)
        val msgs = listOf(ChatMsg("system", SystemPrompt.build(level, device))) + history
        val states = mutableListOf<ProviderState>()
        var lastError: String? = null
        for (p in providers) {
            if (!p.configured()) { states += ProviderState(p.name, "غير مفعّل أو مش متظبط"); continue }
            if (p.id != "local" && !online) { states += ProviderState(p.name, "مفيش إنترنت"); continue }
            try {
                val out = withTimeout(45_000) { p.chat(msgs) }
                if (out.isBlank()) throw IllegalStateException("رد فاضي")
                states += ProviderState(p.name, "شغّال")
                _status.value = AiStatus(p.name, true, lastError, states.toList(), online)
                return AiResult(out, p.name, true)
            } catch (e: TimeoutCancellationException) {
                lastError = "${p.name}: انتهت المهلة"; states += ProviderState(p.name, "انتهت المهلة")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = "${p.name}: ${e.message ?: e.javaClass.simpleName}"; states += ProviderState(p.name, "فشل: ${e.message}")
            }
        }
        states += ProviderState("وضع القواعد الثابتة", "متاح دايمًا (مش ذكاء توليدي)")
        _status.value = AiStatus("وضع القواعد الثابتة", false, lastError, states.toList(), online)
        return AiResult(rule.reply(history), "وضع القواعد الثابتة", false)
    }

    /** Sends a tiny request to each configured provider and records the outcome (used by the status page). */
    suspend fun probe() {
        val online = isOnline(ctx)
        val states = mutableListOf<ProviderState>()
        var lastError: String? = null
        var current: AiProvider? = null
        for (p in providers) {
            if (!p.configured()) { states += ProviderState(p.name, "غير مفعّل أو مش متظبط"); continue }
            if (p.id != "local" && !online) { states += ProviderState(p.name, "مفيش إنترنت"); continue }
            try {
                val out = withTimeout(20_000) { p.chat(listOf(ChatMsg("user", "رد بكلمة واحدة: تمام"))) }
                if (out.isBlank()) throw IllegalStateException("رد فاضي")
                states += ProviderState(p.name, "شغّال"); if (current == null) current = p
            } catch (e: TimeoutCancellationException) {
                lastError = "${p.name}: انتهت المهلة"; states += ProviderState(p.name, "انتهت المهلة")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = "${p.name}: ${e.message ?: e.javaClass.simpleName}"; states += ProviderState(p.name, "فشل: ${e.message}")
            }
        }
        _status.value = AiStatus(current?.name ?: "وضع القواعد الثابتة", current != null, lastError, states, online)
    }
}
