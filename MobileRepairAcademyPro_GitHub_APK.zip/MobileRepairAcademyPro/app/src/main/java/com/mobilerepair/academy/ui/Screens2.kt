package com.mobilerepair.academy.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.mobilerepair.academy.AppViewModel
import com.mobilerepair.academy.data.*
import com.mobilerepair.academy.search.ConnStatus
import com.mobilerepair.academy.search.SearchRequest

private val LEVELS = listOf("beginner" to "مبتدئ", "intermediate" to "متوسط", "advanced" to "متقدم")

@Composable
fun AssistantScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val msgs by vm.messages.collectAsState()
    val busy by vm.chatBusy.collectAsState()
    val level by vm.level.collectAsState()
    val sessions by vm.sessions.collectAsState()
    val status by vm.ai.status.collectAsState()
    var device by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var measure by remember { mutableStateOf("") }
    var showMeasure by remember { mutableStateOf(false) }
    var showSessions by remember { mutableStateOf(false) }
    var image by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> image = uri?.toString() }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("مهندس الصيانة الذكي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(device, { device = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("الشركة والموديل (مثال: Samsung A10)") })
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            LEVELS.forEach { (k, l) -> FilterChip(selected = level == k, onClick = { vm.setLevel(k) }, label = { Text(l) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton({ vm.newSession() }) { Text("محادثة جديدة") }
            OutlinedButton({ showSessions = true }) { Text("السجل") }
            OutlinedButton({
                shareText(ctx, "تقرير تشخيص — ${device.ifBlank { "جهاز" }}\n\n" + msgs.joinToString("\n\n") { (if (it.role == "user") "أنا: " else "المهندس: ") + it.text })
            }, enabled = msgs.isNotEmpty()) { Text("مشاركة") }
        }
        Text("وضع المساعد: ${status.current}" + if (status.generative) "" else " (مش ذكاء اصطناعي توليدي)", style = MaterialTheme.typography.bodySmall)
        LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (msgs.isEmpty()) item { Card2 { Text("اكتب وصف العطل واسم الموديل، وأنا هسألك عن اللي ناقص وهطلب منك اختبار واحد في كل مرة.") } }
            items(msgs, key = { it.id }) { m ->
                Card(colors = CardDefaults.cardColors(containerColor = if (m.role == "user") MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(if (m.role == "user") "أنت" else "المهندس", fontWeight = FontWeight.Bold)
                        Text(m.text)
                        if (m.role == "assistant") TextButton({ clip.setText(AnnotatedString(m.text)) }) { Text("نسخ") }
                    }
                }
            }
            if (busy) item { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)); Text("بفكر...") } }
        }
        if (image != null) Text("📎 صورة مرفقة هتتحفظ في السجل. التطبيق مش بيحللها آليًا إلا لو مزود يدعم الصور اتضاف.", style = MaterialTheme.typography.bodySmall)
        if (showMeasure) OutlinedTextField(measure, { measure = it }, Modifier.fillMaxWidth(), label = { Text("نتايج القياس (اختياري)") })
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("اكتب العطل أو نتيجة الاختبار...") }, maxLines = 4)
            Column {
                IconButton({ vm.send(text, device, measure, image); text = ""; measure = ""; image = null }, enabled = !busy) {
                    Icon(Icons.AutoMirrored.Filled.Send, "إرسال")
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TextButton({ picker.launch("image/*") }) { Text("📎 صورة") }
            TextButton({ showMeasure = !showMeasure }) { Text("📏 قياسات") }
        }
    }
    if (showSessions) AlertDialog(onDismissRequest = { showSessions = false }, confirmButton = { TextButton({ showSessions = false }) { Text("إغلاق") } },
        title = { Text("سجل التشخيصات") }, text = {
            LazyColumn { if (sessions.isEmpty()) item { Text("مفيش محادثات محفوظة لسه.") }
                items(sessions, key = { it.id }) { s -> TextButton({ vm.openSession(s.id); showSessions = false }) { Text(s.title) } } }
        })
}

@Composable
fun SearchScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val busy by vm.searchBusy.collectAsState()
    val report by vm.searchReport.collectAsState()
    val summary by vm.aiSummary.collectAsState()
    var desc by remember { mutableStateOf(vm.globalQuery.value) }
    var company by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf("") }
    var lang by remember { mutableStateOf("both") }
    var kinds by remember { mutableStateOf(setOf<String>()) }
    val kindNames = listOf("official" to "رسمي", "reference" to "مرجع فني", "forum" to "منتديات", "video" to "فيديو", "general" to "عام")
    Page("ابحث عن عطل") {
        OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth(), label = { Text("وصف العطل") })
        OutlinedTextField(company, { company = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("اسم الشركة") })
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("موديل الجهاز") })
        OutlinedTextField(type, { type = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("نوع العطل (شحن، شاشة، باور...)") })
        OutlinedTextField(extra, { extra = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("كلمات إضافية") })
        Text("لغة النتايج")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("ar" to "عربي", "en" to "إنجليزي", "both" to "الاتنين").forEach { (k, l) ->
                FilterChip(selected = lang == k, onClick = { lang = k }, label = { Text(l) })
            }
        }
        Text("نوع المصدر (من غير اختيار = الكل)")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            kindNames.take(3).forEach { (k, l) -> FilterChip(selected = k in kinds, onClick = { kinds = if (k in kinds) kinds - k else kinds + k }, label = { Text(l) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            kindNames.drop(3).forEach { (k, l) -> FilterChip(selected = k in kinds, onClick = { kinds = if (k in kinds) kinds - k else kinds + k }, label = { Text(l) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.runSearch(SearchRequest(desc, company, model, type, extra, lang, kinds)) },
                enabled = !busy && (desc.isNotBlank() || model.isNotBlank())) { Text("ابحث وحلّل") }
            OutlinedButton({ vm.cancelSearch() }, enabled = busy) { Text("إيقاف البحث") }
        }
        if (busy) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("بدوّر في المحركات المتاحة...") }
        report?.let { rep ->
            if (rep.offline) Warn("مفيش إنترنت. البحث المباشر والمساعد السحابي مش متاحين دلوقتي.")
            Card2 { Text("تقرير الحل", fontWeight = FontWeight.Bold); Text(rep.reportText) }
            summary?.let { Card2 { Text("ملخص الذكاء الاصطناعي (من العناوين والمقتطفات بس)", fontWeight = FontWeight.Bold); Text(it) } }
            Card2 {
                Text("حالة كل مصدر", fontWeight = FontWeight.Bold)
                rep.outcomes.forEach {
                    val icon = when (it.status) { ConnStatus.OK -> "✅"; ConnStatus.FAILED -> "❌"; ConnStatus.UNAVAILABLE -> "⏸️" }
                    Text("$icon ${it.name}: ${it.message}")
                }
            }
            rep.results.forEach { r ->
                Card2(onClick = { openUrl(ctx, r.url) }) {
                    Text(r.title.ifBlank { r.url }, fontWeight = FontWeight.Bold)
                    Text("${r.source} • ${r.kind}", style = MaterialTheme.typography.bodySmall)
                    if (r.snippet.isNotBlank()) Text(r.snippet.take(200))
                }
            }
            if (rep.results.isNotEmpty()) Text("اضغط على أي نتيجة لفتحها في المتصفح وراجع المصدر بنفسك.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun CompatScreen(vm: AppViewModel, nav: NavHostController) {
    var q by remember { mutableStateOf("") }
    val nq = TextUtil.normalize(q)
    val items = vm.content.compat.filter { nq.isBlank() || TextUtil.normalize(it.original + it.alt + it.partNumber).contains(nq) }
    Page("توافق الشاشات وقطع الغيار", { nav.popBackStack() }) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("دوّر بالموديل أو رقم القطعة") })
        if (vm.content.compat.isEmpty()) {
            Card2 {
                Text("قاعدة التوافق فاضية لحد دلوقتي", fontWeight = FontWeight.Bold)
                Text("ما سجّلتش أي علاقة توافق لمجرد تشابه الشكل أو الموصل. أي توافق لازم يتضاف بمصدر وتاريخ تحقق من ملف compat.json أو من مساهمات المستخدمين بعد المراجعة.")
            }
            Button({ nav.navigate("community") }) { Text("اقترح توافق قطعة") }
        }
        items.forEach { c ->
            Card2 {
                Text("${c.original} ⇄ ${c.alt}", fontWeight = FontWeight.Bold)
                Text("النوع: ${c.kind} • رقم القطعة: ${c.partNumber}")
                Text("المصدر: ${c.source} • تاريخ التحقق: ${c.verified}")
                Text("درجة التأكد: ${c.certainty} • المراجعة: ${c.review}")
                if (c.notes.isNotBlank()) Text("ملاحظات التركيب: ${c.notes}")
            }
        }
    }
}

@Composable
fun LibraryScreen(vm: AppViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val nq = TextUtil.normalize(q)
    val items = vm.content.library.filter { nq.isBlank() || TextUtil.normalize(it.company + it.model + it.title + it.kind).contains(nq) }
    Page("المخططات وملفات الصيانة", { nav.popBackStack() }) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الشركة أو الموديل أو نوع الملف") })
        if (vm.content.library.isEmpty()) Card2 {
            Text("المكتبة فاضية لحد دلوقتي", fontWeight = FontWeight.Bold)
            Text("ما حطّيتش مخططات ولا روابط تنزيل مخترعة. أي ملف يتضاف لازم يكون متاح قانونيًا ومعاه مصدره وترخيصه في library.json.")
        }
        items.forEach { li ->
            Card2(onClick = { openUrl(ctx, li.url) }) {
                Text(li.title, fontWeight = FontWeight.Bold)
                Text("${li.company} ${li.model} • ${li.kind} • ${li.source} • ${li.license}")
            }
        }
        Card2 {
            Text("بحث خارجي في المتصفح (مش تحليل آلي)", fontWeight = FontWeight.Bold)
            Button({ openUrl(ctx, "https://www.ifixit.com/Search?query=${com.mobilerepair.academy.search.enc(q)}") }, enabled = q.isNotBlank()) { Text("أدلة iFixit") }
            Button({ openUrl(ctx, "https://www.gsmarena.com/results.php3?sQuickSearch=yes&sName=${com.mobilerepair.academy.search.enc(q)}") }, enabled = q.isNotBlank()) { Text("مواصفات GSMArena") }
        }
    }
}

@Composable
fun CommunityScreen(vm: AppViewModel, nav: NavHostController) {
    val list by vm.contributions.collectAsState()
    val mod by vm.moderatorMode.collectAsState()
    val log by vm.moderationLog.collectAsState()
    val kinds = listOf("عطل جديد", "حل جديد", "تصحيح معلومة", "توافق قطعة", "قياسات فعلية", "صورة توضيحية", "مرجع فني")
    var kind by remember { mutableStateOf(kinds[0]) }
    var model by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var source by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    Page("مجتمع الفنيين", { nav.popBackStack() }) {
        if (!vm.cloud.configured) Warn("الخادم السحابي لسه ما اتظبطش، فمشاركة المعلومات بين الأجهزة مش شغالة. المساهمات بتتحفظ على جهازك بس وجاهزة للربط بعدين.")
        Text("اقترح معلومة جديدة (بتفضل «قيد المراجعة» لحد ما تتراجع)")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { kinds.take(4).forEach { FilterChip(it == kind, { kind = it }, { Text(it) }) } }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { kinds.drop(4).forEach { FilterChip(it == kind, { kind = it }, { Text(it) }) } }
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الموديل") })
        OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth(), label = { Text("الوصف") })
        OutlinedTextField(source, { source = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("المصدر (لو متاح)") })
        Button({ vm.submitContribution(kind, model, desc, source); desc = ""; source = "" }, enabled = model.isNotBlank() && desc.isNotBlank()) { Text("ابعت للمراجعة") }
        Text("مساهماتي", style = MaterialTheme.typography.titleMedium)
        if (list.isEmpty()) Text("لسه مفيش مساهمات.")
        list.forEach { c ->
            Card2 {
                Text("${c.kind} • ${c.model} • الحالة: ${c.status}", fontWeight = FontWeight.Bold)
                Text(c.description)
                if (c.source.isNotBlank()) Text("المصدر: ${c.source}")
                if (mod && c.status == "قيد المراجعة") {
                    OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("ملاحظة المشرف") })
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button({ vm.moderate(c.id, "مقبول", note); note = "" }) { Text("قبول") }
                        OutlinedButton({ vm.moderate(c.id, "مرفوض", note); note = "" }) { Text("رفض") }
                        OutlinedButton({ vm.moderate(c.id, "محتاج معلومات إضافية", note); note = "" }) { Text("طلب معلومات") }
                    }
                }
            }
        }
        if (mod) {
            Warn("لوحة المشرف دي محلية وتجريبية ومش آمنة. الصلاحيات الحقيقية لازم تتفعّل من الخادم.")
            Sect("سجل التغييرات", log.map { "مساهمة #${it.contributionId}: ${it.action} ${it.note}" })
        }
    }
}

@Composable
fun AiStatusScreen(vm: AppViewModel, nav: NavHostController) {
    val st by vm.ai.status.collectAsState()
    val connectors = vm.search.connectors
    Page("حالة الذكاء الاصطناعي والبحث", { nav.popBackStack() }) {
        if (!st.generative) Warn("خدمة الذكاء الاصطناعي مش متاحة دلوقتي. تقدر تجرّب البحث عن العطل من المصادر الخارجية أو ترجع للموسوعة المحفوظة.")
        Card2 {
            Text("المزود الحالي: ${st.current}", fontWeight = FontWeight.Bold)
            Text("اتصال بالإنترنت: ${if (st.online) "موجود" else "مش موجود"}")
            Text("تحليل الصور: ${if (vm.ai.supportsImages) "متاح" else "مش متاح (الصور بتتحفظ بس)"}")
            Text("حدود الاستخدام: الخدمات العامة ممكن يكون ليها حدود مش معروفة مسبقًا، ولو اتعدّت هيظهر الخطأ هنا.")
            Text("آخر خطأ: ${st.lastError ?: "مفيش"}")
        }
        Sect("حالة المزودين", st.states.map { "${it.name}: ${it.state}" }.ifEmpty { listOf("دوس «اختبر الاتصال» علشان تعرف الحالة.") })
        Button({ vm.probeAi() }) { Text("اختبر الاتصال") }
        Sect("محركات البحث", connectors.map { c -> "${c.name}: ${c.missingSetup() ?: "جاهز (مش مضمون إنه شغال لحد ما تجرّب)"}" })
        Sect("البدائل عند توقف الخدمة", listOf("وضع القواعد الثابتة (خطوات تشخيص من قاعدة المعرفة)", "الموسوعة والدروس المحفوظة", "فتح نتايج البحث في المتصفح"))
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavHostController) {
    val theme by vm.themeMode.collectAsState()
    val ads by vm.adsEnabled.collectAsState()
    val mod by vm.moderatorMode.collectAsState()
    val p = vm.prefs
    var aiUrl by remember { mutableStateOf(p.s(K.AI_URL)) }
    var aiKey by remember { mutableStateOf(p.s(K.AI_KEY)) }
    var aiModel by remember { mutableStateOf(p.s(K.AI_MODEL)) }
    var polli by remember { mutableStateOf(p.b(K.POLLINATIONS, true)) }
    var serp by remember { mutableStateOf(p.s(K.OPENSERP)) }
    var brave by remember { mutableStateOf(p.s(K.BRAVE)) }
    var gk by remember { mutableStateOf(p.s(K.GCSE_KEY)) }
    var gcx by remember { mutableStateOf(p.s(K.GCSE_CX)) }
    var yt by remember { mutableStateOf(p.s(K.YT_KEY)) }
    var saved by remember { mutableStateOf(false) }
    Page("الإعدادات", { nav.popBackStack() }) {
        Text("المظهر")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("system" to "حسب الجهاز", "dark" to "داكن", "light" to "فاتح").forEach { (k, l) -> FilterChip(theme == k, { vm.setTheme(k) }, { Text(l) }) }
        }
        Text("مزود ذكاء اصطناعي إضافي (اختياري)", style = MaterialTheme.typography.titleMedium)
        Text("أي خدمة متوافقة مع OpenAI. المفاتيح بتتحفظ على جهازك بس، ومش جوه التطبيق.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(aiUrl, { aiUrl = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الرابط الأساسي (https://.../v1)") })
        OutlinedTextField(aiModel, { aiModel = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("اسم النموذج") })
        OutlinedTextField(aiKey, { aiKey = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("المفتاح (لو مطلوب)") })
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(polli, { polli = it }); Spacer(Modifier.width(8.dp)); Text("جرّب الخدمة العامة التجريبية بدون مفتاح")
        }
        Text("محركات البحث (اختيارية)", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(serp, { serp = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("رابط خادم بحث مجمّع (فيه {q})") })
        OutlinedTextField(brave, { brave = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Brave Search API key") })
        OutlinedTextField(gk, { gk = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Google Custom Search key") })
        OutlinedTextField(gcx, { gcx = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Google Custom Search CX") })
        OutlinedTextField(yt, { yt = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("YouTube Data API key") })
        Button({
            p.put(K.AI_URL, aiUrl.trim()); p.put(K.AI_MODEL, aiModel.trim()); p.put(K.AI_KEY, aiKey.trim()); p.putB(K.POLLINATIONS, polli)
            p.put(K.OPENSERP, serp.trim()); p.put(K.BRAVE, brave.trim()); p.put(K.GCSE_KEY, gk.trim()); p.put(K.GCSE_CX, gcx.trim()); p.put(K.YT_KEY, yt.trim())
            saved = true
        }) { Text("احفظ") }
        if (saved) Text("اتحفظ ✅")
        Text("خيارات متقدمة", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(ads, { vm.setAds(it) }); Spacer(Modifier.width(8.dp)); Text("تفعيل المساحة الإعلانية (تجريبي، من غير SDK)") }
        Row(verticalAlignment = Alignment.CenterVertically) { Switch(mod, { vm.setModerator(it) }); Spacer(Modifier.width(8.dp)); Text("وضع المشرف المحلي (تجريبي)") }
    }
}

@Composable
fun MoreScreen(nav: NavHostController) {
    Page("المزيد") {
        listOf(
            "موسوعة المكونات" to "components", "توافق الشاشات وقطع الغيار" to "compat",
            "المخططات وملفات الصيانة" to "library", "مجتمع الفنيين" to "community",
            "المفضلة وسجل البحث" to "favorites", "حالة الذكاء الاصطناعي والبحث" to "aistatus",
            "الإعدادات" to "settings", "سياسة الخصوصية" to "privacy"
        ).forEach { (l, r) -> FilledTonalButton({ nav.navigate(r) }, Modifier.fillMaxWidth()) { Text(l) } }
    }
}

@Composable
fun PrivacyScreen(nav: NavHostController) {
    Page("سياسة الخصوصية (قالب قابل للتخصيص)", { nav.popBackStack() }) {
        Sect("اللي بيتحفظ", listOf(
            "المحادثات والتشخيصات والمفضلة وتقدمك في الدروس بتتحفظ على جهازك بس.",
            "الصور اللي بترفقها بتتحفظ كمرجع (رابط) في السجل المحلي، ومش بتتبعت لأي خدمة.",
            "لو فعّلت مزود ذكاء اصطناعي أو محرك بحث، نص رسالتك أو كلمات البحث بتتبعت لمزود الخدمة اللي اخترته، وبتخضع لسياسته."
        ))
        Sect("اللي مش بنعمله", listOf("مفيش تتبّع ولا جمع بيانات غير ضرورية.", "المفاتيح اللي بتدخلها بتتحفظ على جهازك ومش جوه ملف التطبيق."))
        Warn("عدّل النص ده وأضف بيانات الجهة المالكة والتواصل قبل النشر على متجر التطبيقات.")
    }
}
