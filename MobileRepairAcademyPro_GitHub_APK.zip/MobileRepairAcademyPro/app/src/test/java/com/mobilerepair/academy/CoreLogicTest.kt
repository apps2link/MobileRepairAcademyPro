package com.mobilerepair.academy

import com.mobilerepair.academy.data.*
import org.junit.Assert.*
import org.junit.Test

class CoreLogicTest {

    @Test fun normalizeUnifiesArabicLetters() {
        assertEquals(TextUtil.normalize("أَحمد"), TextUtil.normalize("احمد"))
        assertEquals(TextUtil.normalize("شاشة"), TextUtil.normalize("شاشه"))
    }

    @Test fun dedupeIgnoresSchemeWwwAndTracking() {
        val a = SearchResult("t", "https://www.example.com/a?utm_source=x", "", "s", "general")
        val b = SearchResult("t2", "http://example.com/a/", "", "s", "general")
        assertEquals(1, ResultRanker.dedupe(listOf(a, b)).size)
    }

    @Test fun rankingPrefersModelMatchAndTrust() {
        val generic = SearchResult("Phone charging tips", "https://a.com/1", "general advice", "x", "general")
        val specific = SearchResult("Samsung A10 not charging fix", "https://b.com/2", "a10 charging port", "iFixit", "reference")
        val ranked = ResultRanker.rank(listOf(generic, specific), "samsung a10 not charging", "a10")
        assertEquals("https://b.com/2", ranked.first().url)
    }

    @Test fun faultMatcherFindsDeadPhoneFlow() {
        val flows = listOf(
            FaultFlow("dead", "dead", listOf("مش بيفتح", "مفيش سحب"), emptyList(), emptyList(), emptyList()),
            FaultFlow("chg", "chg", listOf("مش بيشحن"), emptyList(), emptyList(), emptyList())
        )
        assertEquals("dead", FaultMatcher.match("الجهاز مش بيفتح ومفيش سحب", flows)?.id)
        assertNull(FaultMatcher.match("كلام مالوش علاقة", flows))
    }

    @Test fun emptyResultsStayEmpty() {
        assertTrue(ResultRanker.rank(emptyList(), "q", "m").isEmpty())
    }
}
