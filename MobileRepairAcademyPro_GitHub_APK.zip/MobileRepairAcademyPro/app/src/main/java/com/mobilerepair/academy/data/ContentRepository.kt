package com.mobilerepair.academy.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

private fun JSONArray?.strings(): List<String> =
    if (this == null) emptyList() else List(length()) { optString(it) }

class ContentRepository(private val ctx: Context) {

    private fun read(name: String): JSONArray =
        try {
            JSONArray(ctx.assets.open("content/$name").bufferedReader().use { it.readText() })
        } catch (e: Exception) {
            JSONArray()
        }

    val lessons: List<Lesson> by lazy {
        val a = read("lessons.json")
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            val qz = o.optJSONArray("quiz")
            Lesson(
                o.getString("id"), o.optInt("level", 1), o.getString("title"), o.optString("difficulty"),
                o.optJSONArray("goals").strings(), o.optString("body"), o.optJSONArray("steps").strings(),
                o.optJSONArray("tools").strings(), o.optJSONArray("mistakes").strings(),
                o.optJSONArray("safety").strings(),
                if (qz == null) emptyList() else List(qz.length()) { j ->
                    val q = qz.getJSONObject(j)
                    QuizQ(q.getString("q"), q.optJSONArray("options").strings(), q.optInt("answer"), q.optString("explain"))
                },
                o.optJSONArray("sources").strings(), o.optString("reviewed")
            )
        }
    }

    val components: List<Component> by lazy {
        val a = read("components.json")
        List(a.length()) { i ->
            val o: JSONObject = a.getJSONObject(i)
            Component(
                o.getString("id"), o.getString("nameAr"), o.optString("nameEn"), o.optString("function"),
                o.optString("symbol"), o.optString("identify"), o.optString("measure"), o.optString("meterMode"),
                o.optString("expected"), o.optJSONArray("interpret").strings(), o.optJSONArray("faults").strings(),
                o.optString("example"), o.optJSONArray("sources").strings(), o.optString("reviewed")
            )
        }
    }

    val faults: List<FaultFlow> by lazy {
        val a = read("faults.json")
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            val t = o.optJSONArray("tests")
            FaultFlow(
                o.getString("id"), o.getString("title"), o.optJSONArray("keywords").strings(),
                o.optJSONArray("questions").strings(),
                if (t == null) emptyList() else List(t.length()) { j ->
                    val x = t.getJSONObject(j)
                    FaultTest(x.optString("goal"), x.optString("tools"), x.optString("how"), x.optJSONArray("interpret").strings())
                },
                o.optJSONArray("cautions").strings()
            )
        }
    }

    val library: List<LibraryItem> by lazy {
        val a = read("library.json")
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            LibraryItem(o.optString("id"), o.optString("company"), o.optString("model"), o.optString("kind"),
                o.optString("title"), o.optString("url"), o.optString("source"), o.optString("license"))
        }
    }

    val compat: List<CompatItem> by lazy {
        val a = read("compat.json")
        List(a.length()) { i ->
            val o = a.getJSONObject(i)
            CompatItem(o.optString("original"), o.optString("alt"), o.optString("partNumber"), o.optString("kind"),
                o.optString("source"), o.optString("verified"), o.optString("notes"), o.optString("certainty"), o.optString("review"))
        }
    }
}
