package com.mobilerepair.academy

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.mobilerepair.academy.ai.AIProviderManager
import com.mobilerepair.academy.ai.ChatMsg
import com.mobilerepair.academy.data.*
import com.mobilerepair.academy.search.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

@OptIn(ExperimentalCoroutinesApi::class)
class AppViewModel(app: Application) : AndroidViewModel(app) {
    val db: AppDb = Room.databaseBuilder(app, AppDb::class.java, "academy.db").build()
    private val dao = db.dao()
    val content = ContentRepository(app)
    val prefs = Prefs(app)
    val ai = AIProviderManager(app, prefs, content)
    val search = SearchProviderManager(app, prefs, content)
    val cloud: CloudSync = NoopCloudSync()

    private fun <T> Flow<T>.state(init: T) = stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), init)

    val favorites = dao.favorites().state(emptyList())
    val history = dao.history().state(emptyList())
    val progress = dao.progress().state(emptyList())
    val mistakes = dao.mistakes().state(emptyList())
    val sessions = dao.sessions().state(emptyList())
    val contributions = dao.contributions().state(emptyList())
    val moderationLog = dao.moderationLog().state(emptyList())

    val themeMode = MutableStateFlow(prefs.s(K.THEME, "system"))
    val level = MutableStateFlow(prefs.s(K.LEVEL, "beginner"))
    val adsEnabled = MutableStateFlow(prefs.b(K.ADS, false))
    val moderatorMode = MutableStateFlow(prefs.b(K.MOD, false))
    val globalQuery = MutableStateFlow("")

    fun setTheme(v: String) { prefs.put(K.THEME, v); themeMode.value = v }
    fun setLevel(v: String) { prefs.put(K.LEVEL, v); level.value = v }
    fun setAds(v: Boolean) { prefs.putB(K.ADS, v); adsEnabled.value = v }
    fun setModerator(v: Boolean) { prefs.putB(K.MOD, v); moderatorMode.value = v }

    // ---------- favorites ----------
    fun toggleFavorite(key: String, type: String, title: String) = viewModelScope.launch {
        if (favorites.value.any { it.key == key }) dao.removeFavorite(key)
        else dao.addFavorite(FavoriteEntity(key, type, title, System.currentTimeMillis()))
    }

    fun clearHistory() = viewModelScope.launch { dao.clearHistory() }

    // ---------- learning ----------
    fun markLessonOpened(id: String) = viewModelScope.launch {
        val old = dao.progressOf(id)
        dao.saveProgress(ProgressEntity(id, old?.done ?: false, old?.bestScore ?: 0, System.currentTimeMillis()))
    }

    fun saveQuiz(lesson: Lesson, score: Int, wrong: List<QuizQ>) = viewModelScope.launch {
        val old = dao.progressOf(lesson.id)
        dao.saveProgress(ProgressEntity(lesson.id, true, maxOf(score, old?.bestScore ?: 0), System.currentTimeMillis()))
        wrong.forEach { dao.addMistake(MistakeEntity(lessonId = lesson.id, question = it.q, ts = System.currentTimeMillis())) }
    }

    // ---------- assistant ----------
    val currentSession = MutableStateFlow<Long?>(null)
    val chatBusy = MutableStateFlow(false)
    val messages = currentSession.flatMapLatest { id -> if (id == null) flowOf(emptyList<MessageEntity>()) else dao.messages(id) }.state(emptyList())
    private var chatJob: Job? = null

    fun newSession() { chatJob?.cancel(); chatBusy.value = false; currentSession.value = null }
    fun openSession(id: Long) { currentSession.value = id }

    fun send(text: String, device: String, measure: String, image: String?) {
        if (text.isBlank() && measure.isBlank()) return
        chatJob = viewModelScope.launch {
            var sid = currentSession.value
            if (sid == null) {
                sid = dao.addSession(SessionEntity(title = text.take(40).ifBlank { "تشخيص جديد" }, device = device, ts = System.currentTimeMillis()))
                currentSession.value = sid
            }
            val full = buildString {
                append(text)
                if (measure.isNotBlank()) append("\nنتايج القياس: $measure")
                if (image != null) append("\n[صورة مرفقة — اتحفظت في السجل ومتحللتش آليًا]")
            }
            dao.addMessage(MessageEntity(sessionId = sid, role = "user", text = full, imageUri = image, ts = System.currentTimeMillis()))
            chatBusy.value = true
            try {
                val history = dao.messagesOnce(sid).map { ChatMsg(it.role, it.text) }
                val res = ai.chat(history, level.value, device)
                dao.addMessage(MessageEntity(sessionId = sid, role = "assistant", text = res.text, imageUri = null, ts = System.currentTimeMillis()))
            } finally {
                chatBusy.value = false
            }
        }
    }

    // ---------- search ----------
    val searchBusy = MutableStateFlow(false)
    val searchReport = MutableStateFlow<SearchReport?>(null)
    val aiSummary = MutableStateFlow<String?>(null)
    private var searchJob: Job? = null

    fun runSearch(r: SearchRequest) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            searchBusy.value = true; searchReport.value = null; aiSummary.value = null
            try {
                dao.addHistory(SearchHistoryEntity(query = search.buildQuery(r), ts = System.currentTimeMillis()))
                val rep = search.run(r)
                searchReport.value = rep
                if (rep.results.isNotEmpty()) {
                    val listing = rep.results.take(8).joinToString("\n") { "- ${it.title} (${it.source}): ${it.snippet.take(160)}" }
                    val res = ai.chat(
                        listOf(ChatMsg("user", "لخّص بالمصري من النتايج دي بس، بدون ما تخترع أي معلومة. وضّح إن ده من العناوين والمقتطفات:\n$listing")),
                        level.value, r.model
                    )
                    if (res.generative) aiSummary.value = res.text
                }
            } finally {
                searchBusy.value = false
            }
        }
    }

    fun cancelSearch() { searchJob?.cancel(); searchBusy.value = false }

    // ---------- community ----------
    fun submitContribution(kind: String, model: String, desc: String, source: String) = viewModelScope.launch {
        val c = ContributionEntity(kind = kind, model = model.trim(), description = desc.trim(), source = source.trim(), status = "قيد المراجعة", ts = System.currentTimeMillis())
        val id = dao.addContribution(c)
        cloud.pushContribution(c.copy(id = id))
    }

    fun moderate(id: Long, status: String, note: String) = viewModelScope.launch {
        dao.setStatus(id, status)
        dao.addModerationLog(ModerationLogEntity(contributionId = id, action = status, note = note, ts = System.currentTimeMillis()))
    }

    fun probeAi() = viewModelScope.launch { ai.probe() }

    override fun onCleared() { db.close(); super.onCleared() }
}
