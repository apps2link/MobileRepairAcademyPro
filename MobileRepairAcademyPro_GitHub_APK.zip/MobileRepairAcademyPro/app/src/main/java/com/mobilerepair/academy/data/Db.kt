package com.mobilerepair.academy.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class FavoriteEntity(@PrimaryKey val key: String, val type: String, val title: String, val ts: Long)
@Entity data class SearchHistoryEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val query: String, val ts: Long)
@Entity data class ProgressEntity(@PrimaryKey val lessonId: String, val done: Boolean, val bestScore: Int, val ts: Long)
@Entity data class MistakeEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val lessonId: String, val question: String, val ts: Long)
@Entity data class SessionEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val title: String, val device: String, val ts: Long)
@Entity data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0, val sessionId: Long, val role: String,
    val text: String, val imageUri: String?, val ts: Long
)
@Entity data class ContributionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0, val kind: String, val model: String,
    val description: String, val source: String, val status: String, val ts: Long
)
@Entity data class ModerationLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0, val contributionId: Long,
    val action: String, val note: String, val ts: Long
)

@Dao
interface AppDao {
    @Query("SELECT * FROM FavoriteEntity ORDER BY ts DESC") fun favorites(): Flow<List<FavoriteEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addFavorite(f: FavoriteEntity)
    @Query("DELETE FROM FavoriteEntity WHERE `key` = :key") suspend fun removeFavorite(key: String)

    @Query("SELECT * FROM SearchHistoryEntity ORDER BY ts DESC LIMIT 20") fun history(): Flow<List<SearchHistoryEntity>>
    @Insert suspend fun addHistory(h: SearchHistoryEntity)
    @Query("DELETE FROM SearchHistoryEntity") suspend fun clearHistory()

    @Query("SELECT * FROM ProgressEntity ORDER BY ts DESC") fun progress(): Flow<List<ProgressEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveProgress(p: ProgressEntity)
    @Query("SELECT * FROM ProgressEntity WHERE lessonId = :id") suspend fun progressOf(id: String): ProgressEntity?

    @Query("SELECT * FROM MistakeEntity ORDER BY ts DESC LIMIT 50") fun mistakes(): Flow<List<MistakeEntity>>
    @Insert suspend fun addMistake(m: MistakeEntity)

    @Query("SELECT * FROM SessionEntity ORDER BY ts DESC") fun sessions(): Flow<List<SessionEntity>>
    @Insert suspend fun addSession(s: SessionEntity): Long
    @Query("SELECT * FROM MessageEntity WHERE sessionId = :sid ORDER BY id ASC") fun messages(sid: Long): Flow<List<MessageEntity>>
    @Query("SELECT * FROM MessageEntity WHERE sessionId = :sid ORDER BY id ASC") suspend fun messagesOnce(sid: Long): List<MessageEntity>
    @Insert suspend fun addMessage(m: MessageEntity)

    @Query("SELECT * FROM ContributionEntity ORDER BY ts DESC") fun contributions(): Flow<List<ContributionEntity>>
    @Insert suspend fun addContribution(c: ContributionEntity): Long
    @Query("UPDATE ContributionEntity SET status = :status WHERE id = :id") suspend fun setStatus(id: Long, status: String)
    @Insert suspend fun addModerationLog(l: ModerationLogEntity)
    @Query("SELECT * FROM ModerationLogEntity ORDER BY ts DESC LIMIT 100") fun moderationLog(): Flow<List<ModerationLogEntity>>
}

@Database(
    entities = [
        FavoriteEntity::class, SearchHistoryEntity::class, ProgressEntity::class, MistakeEntity::class,
        SessionEntity::class, MessageEntity::class, ContributionEntity::class, ModerationLogEntity::class
    ],
    version = 1, exportSchema = false
)
abstract class AppDb : RoomDatabase() { abstract fun dao(): AppDao }
