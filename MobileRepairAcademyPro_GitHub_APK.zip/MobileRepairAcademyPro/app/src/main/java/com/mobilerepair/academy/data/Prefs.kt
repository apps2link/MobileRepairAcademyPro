package com.mobilerepair.academy.data

import android.content.Context

/** Plain private SharedPreferences. User-entered keys live only on the device, never in the APK. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun s(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun b(k: String, d: Boolean = false): Boolean = sp.getBoolean(k, d)
    fun putB(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
}

object K {
    const val THEME = "theme"; const val LEVEL = "level"
    const val AI_URL = "ai_url"; const val AI_KEY = "ai_key"; const val AI_MODEL = "ai_model"
    const val POLLINATIONS = "pollinations"
    const val OPENSERP = "openserp_url"; const val BRAVE = "brave_key"
    const val GCSE_KEY = "gcse_key"; const val GCSE_CX = "gcse_cx"; const val YT_KEY = "yt_key"
    const val ADS = "ads_enabled"; const val MOD = "moderator_mode"
}
