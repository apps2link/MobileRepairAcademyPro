package com.mobilerepair.academy.search

import com.mobilerepair.academy.data.*
import org.json.JSONArray
import org.json.JSONObject

enum class ConnStatus { OK, FAILED, UNAVAILABLE }

data class ConnOutcome(val name: String, val status: ConnStatus, val message: String, val results: List<SearchResult> = emptyList())

interface SearchConnector {
    val name: String
    /** General web engines are also run with a "technical sites" query; others run once. */
    val general: Boolean
    /** Null when ready; otherwise a Egyptian-Arabic explanation of what setup is missing. */
    fun missingSetup(): String?
    suspend fun search(q: String): List<SearchResult>
}

private fun arr(o: JSONObject, k: String): JSONArray = o.optJSONArray(k) ?: JSONArray()

class IFixitConnector : SearchConnector {
    override val name = "iFixit"
    override val general = false
    override fun missingSetup(): String? = null
    override suspend fun search(q: String): List<SearchResult> {
        val raw = Http.get("https://www.ifixit.com/api/2.0/search/${enc(q)}?filter=guide&limit=10")
        val a = arr(JSONObject(raw), "results")
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            SearchResult(o.optString("display_title", o.optString("title")), o.optString("url"),
                o.optString("summary"), name, "reference")
        }.filter { it.url.startsWith("http") }
    }
}

class RedditConnector : SearchConnector {
    override val name = "Reddit"
    override val general = false
    override fun missingSetup(): String? = null
    override suspend fun search(q: String): List<SearchResult> {
        val raw = Http.get(
            "https://www.reddit.com/search.json?q=${enc(q)}&limit=10&sort=relevance",
            mapOf("User-Agent" to "MobileRepairAcademy/1.0 (Android educational app)")
        )
        val a = arr(JSONObject(raw).optJSONObject("data") ?: JSONObject(), "children")
        return List(a.length()) { i ->
            val d = a.getJSONObject(i).optJSONObject("data") ?: JSONObject()
            SearchResult(d.optString("title"), "https://www.reddit.com" + d.optString("permalink"),
                d.optString("selftext").take(240), "Reddit r/" + d.optString("subreddit"), "forum")
        }.filter { it.title.isNotBlank() }
    }
}

class DuckDuckGoInstantConnector : SearchConnector {
    override val name = "DuckDuckGo (إجابات فورية فقط)"
    override val general = false
    override fun missingSetup(): String? = null
    override suspend fun search(q: String): List<SearchResult> {
        val raw = Http.get("https://api.duckduckgo.com/?q=${enc(q)}&format=json&no_html=1&skip_disambig=1")
        val o = JSONObject(raw)
        val out = mutableListOf<SearchResult>()
        if (o.optString("AbstractURL").isNotBlank())
            out += SearchResult(o.optString("Heading"), o.optString("AbstractURL"), o.optString("AbstractText"), name, "reference")
        val rel = arr(o, "RelatedTopics")
        for (i in 0 until rel.length()) {
            val r = rel.optJSONObject(i) ?: continue
            if (r.optString("FirstURL").isNotBlank())
                out += SearchResult(r.optString("Text").take(90), r.optString("FirstURL"), r.optString("Text"), name, "general")
        }
        return out
    }
}

class BraveConnector(private val prefs: Prefs) : SearchConnector {
    override val name = "Brave Search (API)"
    override val general = true
    override fun missingSetup() = if (prefs.s(K.BRAVE).isBlank()) "محتاج مفتاح Brave Search API من الإعدادات" else null
    override suspend fun search(q: String): List<SearchResult> {
        val raw = Http.get("https://api.search.brave.com/res/v1/web/search?q=${enc(q)}&count=10",
            mapOf("X-Subscription-Token" to prefs.s(K.BRAVE)))
        val a = arr(JSONObject(raw).optJSONObject("web") ?: JSONObject(), "results")
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            SearchResult(o.optString("title"), o.optString("url"), o.optString("description"), name, "general")
        }
    }
}

class GoogleCseConnector(private val prefs: Prefs) : SearchConnector {
    override val name = "Google (Custom Search API)"
    override val general = true
    override fun missingSetup() =
        if (prefs.s(K.GCSE_KEY).isBlank() || prefs.s(K.GCSE_CX).isBlank()) "محتاج مفتاح وCX لـ Google Custom Search من الإعدادات" else null
    override suspend fun search(q: String): List<SearchResult> {
        val raw = Http.get("https://www.googleapis.com/customsearch/v1?key=${enc(prefs.s(K.GCSE_KEY))}&cx=${enc(prefs.s(K.GCSE_CX))}&q=${enc(q)}")
        val a = arr(JSONObject(raw), "items")
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            SearchResult(o.optString("title"), o.optString("link"), o.optString("snippet"), name, "general")
        }
    }
}

class YouTubeConnector(private val prefs: Prefs) : SearchConnector {
    override val name = "YouTube (API)"
    override val general = false
    override fun missingSetup() = if (prefs.s(K.YT_KEY).isBlank()) "محتاج مفتاح YouTube Data API من الإعدادات" else null
    override suspend fun search(q: String): List<SearchResult> {
        val raw = Http.get("https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=8&q=${enc(q)}&key=${enc(prefs.s(K.YT_KEY))}")
        val a = arr(JSONObject(raw), "items")
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            val id = o.optJSONObject("id")?.optString("videoId").orEmpty()
            val sn = o.optJSONObject("snippet") ?: JSONObject()
            SearchResult(sn.optString("title"), "https://www.youtube.com/watch?v=$id", sn.optString("description").take(200), name, "video")
        }.filter { !it.url.endsWith("v=") }
    }
}

/**
 * Optional self-hosted aggregator server (e.g. an OpenSERP instance). The URL template must contain {q}.
 * The response format was NOT verified at build time; the parser accepts a JSON array or an object with "results".
 */
class OpenSerpConnector(private val prefs: Prefs) : SearchConnector {
    override val name = "خادم بحث مجمّع (OpenSERP أو مشابه)"
    override val general = true
    override fun missingSetup() =
        if (!prefs.s(K.OPENSERP).contains("{q}")) "محتاج تشغّل خادم بحث مجمّع وتحط رابطه في الإعدادات (لازم يحتوي {q})" else null
    override suspend fun search(q: String): List<SearchResult> {
        val raw = Http.get(prefs.s(K.OPENSERP).replace("{q}", enc(q)), timeoutMs = 25000).trim()
        val a = if (raw.startsWith("[")) JSONArray(raw) else arr(JSONObject(raw), "results")
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            SearchResult(o.optString("title"), o.optString("url", o.optString("link")),
                o.optString("description", o.optString("snippet")), name, "general")
        }.filter { it.url.startsWith("http") }
    }
}
