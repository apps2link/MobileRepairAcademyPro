package com.mobilerepair.academy.ai

import com.mobilerepair.academy.data.*
import com.mobilerepair.academy.search.Http
import org.json.JSONArray
import org.json.JSONObject

data class ChatMsg(val role: String, val content: String)
data class AiResult(val text: String, val provider: String, val generative: Boolean)

interface AiProvider {
    val id: String
    val name: String
    val supportsImages: Boolean
    /** True when the provider has everything it needs to be tried (not that it is reachable). */
    fun configured(): Boolean
    suspend fun chat(messages: List<ChatMsg>): String
}

object SystemPrompt {
    fun build(level: String, device: String): String = """
أنت «مهندس الصيانة الذكي»، فني صيانة موبايلات محترف بتشرح بالعامية المصرية البسيطة لفني مبتدئ.
مستوى الشرح المطلوب: ${when (level) { "advanced" -> "متقدم"; "intermediate" -> "متوسط"; else -> "مبتدئ" }}.
الجهاز: ${device.ifBlank { "لسه ما اتحددش" }}.
القواعد:
- ما تخترعش أرقام مكونات أو مسارات أو قيم قياس. لو مش متأكد قول كده بوضوح.
- ما تنسبش معلومة لمخطط ما قريتوش.
- فرّق بين المعلومة المؤكدة والاحتمال.
- اسأل عن المعلومات الناقصة الأول (الموديل، حالة البطارية، الصيانة السابقة، نتايج القياس).
- اطلب اختبار واحد مناسب في كل مرة، اشرح طريقته وسببه، واستنى النتيجة.
- ما تقترحش تغيير آيسي قبل التحقق من الأسباب الأبسط.
- حذّر من القصر وحقن الجهد، وما تطلبش توصيل مصدر طاقة بنقطة مجهولة.
- ما تقولش إنك حللت صورة؛ أنت مش شايف أي صورة.
""".trimIndent()
}

private fun toJsonMessages(messages: List<ChatMsg>): JSONArray = JSONArray().also { arr ->
    messages.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
}

private fun parseOpenAi(raw: String): String =
    JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content").trim()

/** Placeholder: no on-device model runtime is bundled. Add one (e.g. MediaPipe LLM) and implement chat(). */
class LocalModelProvider : AiProvider {
    override val id = "local"
    override val name = "نموذج محلي على الجهاز"
    override val supportsImages = false
    override fun configured() = false
    override suspend fun chat(messages: List<ChatMsg>): String = throw IllegalStateException("مفيش نموذج محلي متثبت")
}

/** Any OpenAI-compatible endpoint the user adds in Settings (own server, LM Studio, Ollama gateway, hosted API...). */
class OpenAiCompatProvider(private val prefs: Prefs) : AiProvider {
    override val id = "openai_compat"
    override val name = "مزود متوافق مع OpenAI (من الإعدادات)"
    override val supportsImages = false
    override fun configured() = prefs.s(K.AI_URL).isNotBlank() && prefs.s(K.AI_MODEL).isNotBlank()
    override suspend fun chat(messages: List<ChatMsg>): String {
        val base = prefs.s(K.AI_URL).trim().trimEnd('/')
        val body = JSONObject().put("model", prefs.s(K.AI_MODEL)).put("messages", toJsonMessages(messages))
        val headers = if (prefs.s(K.AI_KEY).isNotBlank()) mapOf("Authorization" to "Bearer ${prefs.s(K.AI_KEY)}") else emptyMap()
        return parseOpenAi(Http.postJson("$base/chat/completions", body.toString(), headers))
    }
}

/**
 * Candidate keyless public service. Availability, stability and usage limits are NOT guaranteed
 * and were not verified at build time: the app probes it at runtime and falls back if it fails.
 */
class PublicKeylessProvider(private val prefs: Prefs) : AiProvider {
    override val id = "public_keyless"
    override val name = "خدمة عامة بدون مفتاح (تجريبية)"
    override val supportsImages = false
    override fun configured() = prefs.b(K.POLLINATIONS, true)
    override suspend fun chat(messages: List<ChatMsg>): String {
        val body = JSONObject().put("model", "openai").put("messages", toJsonMessages(messages))
        return parseOpenAi(Http.postJson("https://text.pollinations.ai/openai", body.toString()))
    }
}

/** Always-available fallback. It is NOT a generative model; it only walks saved diagnostic flows. */
class RuleBasedProvider(private val content: ContentRepository) {
    fun reply(messages: List<ChatMsg>): String {
        val users = messages.filter { it.role == "user" }
        val all = users.joinToString(" ") { it.content }
        val flow = FaultMatcher.match(all, content.faults)
        val sb = StringBuilder()
        sb.appendLine("⚙️ أنا شغّال دلوقتي بوضع القواعد الثابتة (مش ذكاء اصطناعي توليدي)، فهمشي معاك على خطوات تشخيص عامة من قاعدة المعرفة المحفوظة.")
        sb.appendLine()
        if (flow == null) {
            val toks = TextUtil.tokens(all)
            val lessons = content.lessons.filter { l -> toks.any { TextUtil.normalize(l.title).contains(it) } }.take(3)
            val comps = content.components.filter { c -> toks.any { TextUtil.normalize(c.nameAr + " " + c.nameEn).contains(it) } }.take(3)
            sb.appendLine("ما قدرتش أحدد نوع العطل من كلامك. عشان نبدأ صح، قولي:")
            listOf("الشركة والموديل بالظبط", "العطل بيظهر إزاي", "حالة البطارية والشاحن", "فيه سقوط أو مية أو صيانة قبل كده؟", "أي قياسات عملتها")
                .forEach { sb.appendLine("• $it") }
            if (lessons.isNotEmpty()) { sb.appendLine(); sb.appendLine("دروس ممكن تفيدك: " + lessons.joinToString("، ") { it.title }) }
            if (comps.isNotEmpty()) { sb.appendLine("مكونات مرتبطة: " + comps.joinToString("، ") { it.nameAr }) }
            return sb.toString().trim()
        }
        sb.appendLine("🔎 أقرب حالة في قاعدة المعرفة: ${flow.title}")
        sb.appendLine()
        if (users.size <= 1) {
            sb.appendLine("الأول محتاج أعرف:")
            flow.questions.forEach { sb.appendLine("• $it") }
            sb.appendLine()
        }
        val t = flow.tests.firstOrNull()
        if (t != null) {
            sb.appendLine("الاختبار المقترح دلوقتي:")
            sb.appendLine("الهدف: ${t.goal}")
            sb.appendLine("الأدوات: ${t.tools}")
            sb.appendLine("الطريقة: ${t.how}")
            sb.appendLine()
            sb.appendLine("احتمالات تفسير النتيجة (احتمالات مش حكم نهائي):")
            t.interpret.forEach { sb.appendLine("• $it") }
        }
        sb.appendLine()
        flow.cautions.forEach { sb.appendLine("⚠️ $it") }
        sb.appendLine()
        sb.appendLine("ابعتلي نتيجة الاختبار. ولو عايز تحليل أعمق، فعّل مزود ذكاء اصطناعي من الإعدادات أو جرّب «ابحث عن عطل».")
        return sb.toString().trim()
    }
}
