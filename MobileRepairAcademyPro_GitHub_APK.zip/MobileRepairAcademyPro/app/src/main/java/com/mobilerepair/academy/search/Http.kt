package com.mobilerepair.academy.search

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

fun isOnline(ctx: Context): Boolean {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

/** Minimal HTTPS client. It never tries to bypass logins, CAPTCHAs or rate limits: any 4xx/5xx is reported as a failure. */
object Http {
    suspend fun get(url: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 12000): String =
        request("GET", url, null, headers, timeoutMs)

    suspend fun postJson(url: String, body: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 40000): String =
        request("POST", url, body, headers, timeoutMs)

    private suspend fun request(
        method: String, url: String, body: String?, headers: Map<String, String>, timeoutMs: Int
    ): String = withContext(Dispatchers.IO) {
        if (!url.startsWith("https://")) throw IOException("الرابط لازم يبدأ بـ https")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("Accept", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code")
            text
        } finally {
            c.disconnect()
        }
    }
}
