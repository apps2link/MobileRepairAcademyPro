package com.mobilerepair.academy.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.mobilerepair.academy.AppViewModel
import com.mobilerepair.academy.data.*

@Composable
fun AppRoot(vm: AppViewModel) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Triple("home", "الرئيسية", Icons.Default.Home),
        Triple("academy", "الأكاديمية", Icons.Default.Star),
        Triple("assistant", "المهندس", Icons.Default.Build),
        Triple("search", "بحث", Icons.Default.Search),
        Triple("more", "المزيد", Icons.Default.Menu)
    )
    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEach { (r, l, i) ->
                NavigationBarItem(selected = route == r, onClick = { nav.go(r) }, icon = { Icon(i, l) }, label = { Text(l) })
            }
        }
    }) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad).fillMaxSize()) {
            composable("home") { HomeScreen(vm, nav) }
            composable("academy") { AcademyScreen(vm, nav) }
            composable("lesson/{id}", listOf(navArgument("id") { type = NavType.StringType })) {
                LessonScreen(vm, nav, it.arguments?.getString("id").orEmpty())
            }
            composable("quiz/{id}", listOf(navArgument("id") { type = NavType.StringType })) {
                QuizScreen(vm, nav, it.arguments?.getString("id").orEmpty())
            }
            composable("components") { ComponentsScreen(vm, nav) }
            composable("component/{id}", listOf(navArgument("id") { type = NavType.StringType })) {
                ComponentScreen(vm, nav, it.arguments?.getString("id").orEmpty())
            }
            composable("assistant") { AssistantScreen(vm) }
            composable("search") { SearchScreen(vm) }
            composable("compat") { CompatScreen(vm, nav) }
            composable("library") { LibraryScreen(vm, nav) }
            composable("community") { CommunityScreen(vm, nav) }
            composable("favorites") { FavoritesScreen(vm, nav) }
            composable("aistatus") { AiStatusScreen(vm, nav) }
            composable("settings") { SettingsScreen(vm, nav) }
            composable("privacy") { PrivacyScreen(nav) }
            composable("more") { MoreScreen(nav) }
        }
    }
}

@Composable
fun HomeScreen(vm: AppViewModel, nav: NavHostController) {
    var q by remember { mutableStateOf("") }
    val progress by vm.progress.collectAsState()
    val favs by vm.favorites.collectAsState()
    val hist by vm.history.collectAsState()
    val ads by vm.adsEnabled.collectAsState()
    val lessons = vm.content.lessons
    Page("أهلًا بيك في الأكاديمية 👋") {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("دوّر على درس أو مكوّن أو عطل...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { if (q.isNotBlank()) { vm.globalQuery.value = q; nav.go("search") } })
        )
        if (q.isNotBlank()) {
            val nq = TextUtil.normalize(q)
            val ls = lessons.filter { TextUtil.normalize(it.title + " " + it.body).contains(nq) }.take(5)
            val cs = vm.content.components.filter { TextUtil.normalize(it.nameAr + " " + it.nameEn).contains(nq) }.take(5)
            Card2 {
                Text("نتايج من المحتوى المحفوظ", fontWeight = FontWeight.Bold)
                if (ls.isEmpty() && cs.isEmpty()) Text("مفيش نتايج محلية للكلمة دي.")
                ls.forEach { TextButton({ nav.navigate("lesson/${it.id}") }) { Text("درس: ${it.title}") } }
                cs.forEach { TextButton({ nav.navigate("component/${it.id}") }) { Text("مكوّن: ${it.nameAr}") } }
                Button({ vm.globalQuery.value = q; nav.go("search") }) { Text("ابحث عن العطل على الإنترنت") }
            }
        }
        Button(onClick = { nav.go("assistant") }, modifier = Modifier.fillMaxWidth().height(64.dp)) {
            Icon(Icons.Default.Build, null); Spacer(Modifier.width(8.dp))
            Text("مهندس الصيانة الذكي", style = MaterialTheme.typography.titleMedium)
        }
        val actions = listOf(
            "ابحث عن عطل" to "search", "حلل صورة بوردة" to "assistant",
            "موسوعة المكونات" to "components", "توافق الشاشات وقطع الغيار" to "compat",
            "الكورسات" to "academy", "المخططات وملفات الصيانة" to "library",
            "مجتمع الفنيين" to "community", "المفضلة" to "favorites"
        )
        actions.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { (label, r) ->
                    FilledTonalButton(onClick = { nav.go(r) }, modifier = Modifier.weight(1f)) { Text(label) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        val last = progress.firstOrNull()?.let { p -> lessons.find { it.id == p.lessonId } }
        if (last != null) Card2(onClick = { nav.navigate("lesson/${last.id}") }) {
            Text("كمّل من حيث وقفت", fontWeight = FontWeight.Bold); Text(last.title)
        }
        Sect("أعطال شائعة (من قاعدة المعرفة)", vm.content.faults.map { it.title })
        Sect("آخر المعلومات الفنية المراجعة", vm.content.components.sortedByDescending { it.reviewed }.take(3).map { "${it.nameAr} — آخر مراجعة ${it.reviewed}" })
        Sect("المفضلة", favs.take(5).map { it.title })
        Sect("آخر عمليات البحث", hist.take(5).map { it.query })
        if (ads) Card2 { Text("مساحة إعلانية (وضع تجريبي)") }
    }
}

@Composable
fun AcademyScreen(vm: AppViewModel, nav: NavHostController) {
    val prog by vm.progress.collectAsState()
    val mistakes by vm.mistakes.collectAsState()
    val done = prog.filter { it.done }.associate { it.lessonId to it.bestScore }
    Page("الأكاديمية") {
        Text("اتعلم من الصفر لحد الاحتراف. دي مجموعة تأسيسية من الدروس، والنظام مصمم تضيف عليه دروس جديدة من ملف lessons.json.")
        vm.content.lessons.groupBy { it.level }.toSortedMap().forEach { (lv, ls) ->
            Text(LEVEL_NAMES[lv] ?: "مستوى $lv", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            ls.forEach { l ->
                Card2(onClick = { nav.navigate("lesson/${l.id}") }) {
                    Text((if (done.containsKey(l.id)) "✅ " else "") + l.title, fontWeight = FontWeight.Bold)
                    Text("المستوى: ${l.difficulty}" + (done[l.id]?.let { " — أفضل نتيجة: $it" } ?: ""))
                }
            }
        }
        Text("الدروس الفاضية في المستويات 2 و4 و6 (وتخصص الشركات) لسه محتاجة محتوى حقيقي، ومش هعرضها كعناوين فاضية.", style = MaterialTheme.typography.bodySmall)
        if (mistakes.isNotEmpty()) Sect("أسئلة غلطت فيها قبل كده (راجعها)", mistakes.take(10).map { it.question })
    }
}

@Composable
fun LessonScreen(vm: AppViewModel, nav: NavHostController, id: String) {
    val lesson = vm.content.lessons.find { it.id == id }
    val favs by vm.favorites.collectAsState()
    if (lesson == null) { Page("الدرس مش موجود", { nav.popBackStack() }) { Text("جرّب ترجع للأكاديمية.") }; return }
    LaunchedEffect(id) { vm.markLessonOpened(id) }
    val key = "lesson:$id"
    Page(lesson.title, { nav.popBackStack() }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip(onClick = {}, label = { Text("المستوى: ${lesson.difficulty}") })
            OutlinedButton({ vm.toggleFavorite(key, "درس", lesson.title) }) {
                Text(if (favs.any { it.key == key }) "★ في المفضلة" else "☆ أضف للمفضلة")
            }
        }
        Sect("أهداف التعلم", lesson.goals)
        Para("الشرح", lesson.body)
        Sect("الخطوات العملية", lesson.steps)
        Sect("الأدوات المطلوبة", lesson.tools)
        Sect("الأخطاء الشائعة", lesson.mistakes)
        if (lesson.safety.isNotEmpty()) lesson.safety.forEach { Warn(it) }
        Sect("مصادر ومراجع (آخر مراجعة ${lesson.reviewed})", lesson.sources)
        if (lesson.quiz.isNotEmpty()) Button({ nav.navigate("quiz/$id") }, Modifier.fillMaxWidth()) { Text("ابدأ الاختبار القصير") }
    }
}

@Composable
fun QuizScreen(vm: AppViewModel, nav: NavHostController, id: String) {
    val lesson = vm.content.lessons.find { it.id == id }
    if (lesson == null || lesson.quiz.isEmpty()) { Page("اختبار", { nav.popBackStack() }) { Text("مفيش اختبار للدرس ده.") }; return }
    var idx by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val wrong = remember { mutableStateListOf<QuizQ>() }
    Page("اختبار: ${lesson.title}", { nav.popBackStack() }) {
        if (finished) {
            Card2 {
                Text("نتيجتك: $score من ${lesson.quiz.size}", style = MaterialTheme.typography.titleMedium)
                wrong.forEach { Text("راجع: ${it.q}\n${it.explain}") }
            }
            Button({ nav.popBackStack() }) { Text("رجوع للدرس") }
        } else {
            val q = lesson.quiz[idx]
            Card2 {
                Text("سؤال ${idx + 1} من ${lesson.quiz.size}")
                Text(q.q, fontWeight = FontWeight.Bold)
                q.options.forEachIndexed { i, o ->
                    val mark = when { sel != null && i == q.answer -> "✅ "; sel == i -> "❌ "; else -> "" }
                    OutlinedButton(onClick = {
                        if (sel == null) { sel = i; if (i == q.answer) score++ else wrong.add(q) }
                    }, modifier = Modifier.fillMaxWidth()) { Text(mark + o) }
                }
                if (sel != null) {
                    Text(q.explain)
                    val last = idx + 1 >= lesson.quiz.size
                    Button({
                        if (last) { finished = true; vm.saveQuiz(lesson, score, wrong.toList()) } else { idx++; sel = null }
                    }) { Text(if (last) "خلّص" else "السؤال اللي بعده") }
                }
            }
        }
    }
}

@Composable
fun ComponentsScreen(vm: AppViewModel, nav: NavHostController) {
    var q by remember { mutableStateOf("") }
    Page("موسوعة المكونات", { nav.popBackStack() }) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("دوّر على مكوّن...") })
        val nq = TextUtil.normalize(q)
        vm.content.components.filter { nq.isBlank() || TextUtil.normalize(it.nameAr + " " + it.nameEn).contains(nq) }.forEach { c ->
            Card2(onClick = { nav.navigate("component/${c.id}") }) {
                Text("${c.nameAr} — ${c.nameEn}", fontWeight = FontWeight.Bold); Text(c.function)
            }
        }
    }
}

@Composable
fun ComponentScreen(vm: AppViewModel, nav: NavHostController, id: String) {
    val c = vm.content.components.find { it.id == id }
    val favs by vm.favorites.collectAsState()
    if (c == null) { Page("المكوّن مش موجود", { nav.popBackStack() }) { }; return }
    val key = "component:$id"
    Page("${c.nameAr} (${c.nameEn})", { nav.popBackStack() }) {
        OutlinedButton({ vm.toggleFavorite(key, "مكوّن", c.nameAr) }) { Text(if (favs.any { it.key == key }) "★ في المفضلة" else "☆ أضف للمفضلة") }
        Para("وظيفته", c.function)
        Para("الرمز الإلكتروني", c.symbol)
        Para("إزاي تتعرف عليه على البوردة", c.identify)
        Para("إزاي تقيسه", c.measure)
        Para("وضع الأفوميتر المناسب", c.meterMode)
        Para("القيم المتوقعة", c.expected)
        Sect("تفسير النتايج", c.interpret)
        Sect("الأعطال المحتملة", c.faults)
        Para("مثال عملي", c.example)
        Warn("القياسات بتختلف حسب تصميم الدايرة والموديل وحالة الجهاز. ما تعتبرش قيمة واحدة مناسبة لكل الهواتف.")
        Sect("مصادر (آخر مراجعة ${c.reviewed})", c.sources)
    }
}

@Composable
fun FavoritesScreen(vm: AppViewModel, nav: NavHostController) {
    val favs by vm.favorites.collectAsState()
    val hist by vm.history.collectAsState()
    Page("المفضلة وسجل البحث", { nav.popBackStack() }) {
        if (favs.isEmpty()) Text("لسه مفيش مفضلة. اضغط ☆ جوه أي درس أو مكوّن.")
        favs.forEach { f ->
            Card2(onClick = {
                val (type, id) = f.key.split(":", limit = 2).let { it[0] to it.getOrElse(1) { "" } }
                when (type) { "lesson" -> nav.navigate("lesson/$id"); "component" -> nav.navigate("component/$id"); else -> {} }
            }) { Text("${f.type}: ${f.title}") }
        }
        Sect("سجل البحث", hist.map { it.query })
        if (hist.isNotEmpty()) OutlinedButton({ vm.clearHistory() }) { Text("امسح سجل البحث") }
    }
}
